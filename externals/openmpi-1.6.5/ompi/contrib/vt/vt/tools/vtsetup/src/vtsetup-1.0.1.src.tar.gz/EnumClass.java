/**
 * VampirTrace
 * http://www.tu-dresden.de/zih/vampirtrace
 *
 * Copyright (c) 2005-2013, ZIH, TU Dresden, Federal Republic of Germany
 *
 * Copyright (c) 1998-2005, Forschungszentrum Juelich, Juelich Supercomputing
 *                          Centre, Federal Republic of Germany
 *
 * See the file COPYING in the package base directory for details
 **/

package xmlObjects;

import java.util.ArrayList;


/******
 * 
 * @author Mathias Korepkat
***/
/***
 *	This class contains informations about Enumerations given by the gui_VTSetup.xml
 */
public class EnumClass {
	private String id = new String();
	private ArrayList<String> entry = new ArrayList<String>();
	
	/***
	 * initialization
	 * @param id String that represent a individual id
	 */
	public EnumClass(String id)
	{
		this.id = id;
	}
	
	/***
	 * returns all Entrys ot this enumerations
	 * @return ArrayList of all 
	 */
	public ArrayList<String> getEntrys()
	{
		return this.entry;
	}
	
	/***
	 * returns the id
	 * @return String that represent an individual id of this enumeration
	 */
	public String getId()
	{
		return this.id;
	}
}
